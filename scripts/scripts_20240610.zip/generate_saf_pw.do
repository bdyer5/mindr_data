 cd "./"
#delimit ;
clear;
/*wef*/
set more off;
set memory 700m;

capture log close;
log using "..\datasets\logs\saf_pw.log", replace;
odbc load,exec("
select 
uid,
tlpin,
sector,
hhid,
hhchange,
newhhid,
idenconf,
sawkint,
sadate,
workerid,
sastatus,
sadoc,
sadod,
sadaydrink,
sadawtwat,
sadawtwatc,
sadawata,
sadawatatc,
sadafdrink,
sadafdrinkwt,
sadawtjpp,
sadajppb,
sadamett,
sadawhr,
sadafmv,
sadasmv,
sadpydrink,
sadpwtwat,
sadpfdrink,
sadpyjpp,
sadpmett,
version,
today,
start,
[end],
sadf1,
sadfp1,
formorder,
duplicate
from [mindr-live].dbo.safpw_mv 
") dsn("rammps");

fixdate sadate;

#delimit cr


save "..\datasets\stata\saf_pw.dta", replace
saveold "..\datasets\stata\saf_pw.dta", replace version(12)
log close
