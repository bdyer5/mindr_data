 cd "./"
#delimit ;
clear;
/*wef*/
set more off;
set memory 700m;

capture log close;
log using "..\datasets\logs\wmf_pw.log", replace;
odbc load,exec("
select 
uid,
tlpin,
sector,
hhid,
hhchange,
newhhid,
/*womname,*/
/*husbname,*/
idenconf,
convert(smalldatetime,wmdate,121) as wmdate,
workerid,
wmstatus,
wmdoc,
wmdod,
wmvmt7,
wmdiar7,
wmtoes7,
wmrash7,
wmhair7,
wmweak7,
wmhach7,
wmvision7,
wmbleed7,
wmdys7,
wmbruis7,
wmodor7,
/*serfgen,*/
version,
today,
start,
[end],
formorder,
scheduleid

from [mindr-live].dbo.all_wmf_pw wmp
join shapla.dbo.JiVitAWeek jw on jw.RomanDate = convert(smalldatetime,wmp.wmdate,121)
where duplicate is null


") dsn("rammps");

fixdate wmdate;

#delimit cr


save "..\datasets\stata\wmf_pw.dta", replace
saveold "..\datasets\stata\wmf_pw.dta", replace version(12)
log close
